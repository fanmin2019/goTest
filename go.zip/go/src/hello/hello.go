package main
//https://qiita.com/__init__/items/145462cdbb0f569a29cf
import (
    "log"
    "net/http"
    "fmt"
    "../mux"
    //"../pq"
    //"../gotenv"
    "reflect"
    "strconv"
    "encoding/json"
    "time"
    // "sort"
)

//curl http://localhost:8000/articles
//curl -s -XPOST -d' {"title":"Musk","author":"bin","year":"2019"}' http://localhost:8000/articles
//curl -s -XPOST -d'{"firstname":"Elon","lastname":"Musk","age":48}' http://localhost:8080/decode
//curl -d '{"title":"Musk"}' -H "Content-Type: application/json" -X POST http://localhost:8000/articles

type Article struct {
    ID       int    `json:"id"`
    Title    string `json:"title"`
    Author   string `json:"author"`
    PostDate string `json:"year"`
}

// スライスを用意
var articles []Article
var purchasers []Purchaser
var products []Product
var purchaserProducts []PurchaserProduct

func getArticles(w http.ResponseWriter, r *http.Request) {
      // strct を json に変換
    json.NewEncoder(w).Encode(articles)
}

type Purchaser struct {
    ID       int    `json:id`
    Name    string `json:name`
    CreatedDate   string `json:createddate`
}

type Product struct {
  ID       int    `json:id`
  Name    string `json:name`
  CreatedDate   string `json:createddate`
}

// type PurchaserProduct struct {
//   Purchaser_id       int    `json:purchaser_id`
//   Product_id    int `json:product_id`
//   Purchase_timestamp   string `json:purchase_timestamp`
// }

// func getArticles(w http.ResponseWriter, r *http.Request) {
//     log.Printf("Get all articles")
// }

func getArticle(w http.ResponseWriter, r *http.Request) {
  // get http://localhost:8000/books/hoge -> hoge を取得
  params := mux.Vars(r)
  log.Println(params) // map[id:1]

  // /What's params type?
  log.Println(reflect.TypeOf(params["id"])) // -> Get String

  // Convert Type from String -> Int
  // Not handling err -> _
  i, _ := strconv.Atoi(params["id"])

  // URL に指定した ID の情報を取得
  for _, article := range articles {
      if article.ID == i {
          json.NewEncoder(w).Encode(&article)
      }
  }
}

func addPurchaser(w http.ResponseWriter, r *http.Request) {
    log.Println("Add purchaser is called")
    //log.Println(r.Body)
    var purchaser Purchaser
    // json -> struct
    json.NewDecoder(r.Body).Decode(&purchaser)
    purchaser.ID = len(purchasers) + 1
    t := time.Now()
    // t = time.Unix(t.Unix(), 0)
    purchaser.CreatedDate = t.Format("2006-01-02")
    fmt.Println("purchaser: ", purchaser)
    purchasers = append(purchasers, purchaser)
    json.NewEncoder(w).Encode(purchasers)
  }

/**
curl -d '{"name":"Musk"} -X POST http://localhost:8000/product
*/
func addProduct(w http.ResponseWriter, r *http.Request) {
    log.Println("Add product is called")
    //log.Println(r.Body)
    var product Product
    // json -> struct
    json.NewDecoder(r.Body).Decode(&product)
    product.ID = len(products) + 1
    t := time.Now()
    // t = time.Unix(t.Unix(), 0)
    product.CreatedDate = t.Format("2006-01-02")
    fmt.Println("product: ", product)
    products = append(products, product)
    json.NewEncoder(w).Encode(products)
}

/**
curl -d '{"purchaser_id":"1", "product_id":"5"} -X POST http://localhost:8000/purchaserProduct
*/
func addPurchaserProduct(w http.ResponseWriter, r *http.Request) {
    log.Println("Add PurchaserProduct is called")
    //log.Println(r.Body)
    var pp PurchaserProduct
    // json -> struct
    json.NewDecoder(r.Body).Decode(&pp)
    t := time.Now()
    t = time.Unix(t.Unix(), 0)
    pp.Purchase_timestamp = t.Format("2006-01-02")
    fmt.Println("PurchaserProduct: ", pp)
    purchaserProducts = append(purchaserProducts, pp)
    json.NewEncoder(w).Encode(purchaserProducts)
}

func updateArticle(w http.ResponseWriter, r *http.Request) {
    // log.Println("Update article is called")
    var article Article
    json.NewDecoder(r.Body).Decode(&article)

    for i, item := range articles {
        if item.ID == article.ID {
            articles[i] = article
        }
    }

    json.NewEncoder(w).Encode(article)
}

type PurchaserProduct struct {
  Purchaser_id       int    `json:purchaser_id`
  Product_id    int `json:product_id`
  Purchase_timestamp   string `json:purchase_timestamp`
}

type SampleProduct struct {
  Product       string    `json:product`
}

/**
 "purchases" : {
       "2019-05-10": [
           {
           "product": "Birthday cake"
           },
           {
           "product": "Trumpet"
           }
       ],
     "2019-04-01": [
         {
         "product": "Tomato"
         }
     ],
     "2019-03-21": [
         {
         "product": "Trumpet"
         },
         {
         "product": "Diamond"
         }
     ]
 }
}
*/

//
//curl http://localhost:8000/purchaser/1/product?start_date=20190901&end_date=20191010
///purchaser/{$purchaser_id}/product?start_date={$start_date}&end_date={$end_date} endpoint
func getPurchaserProduct(w http.ResponseWriter, r *http.Request) {
  m := make(map[string][]SampleProduct)
  m["2019-03-21"] = append(m["2019-03-21"], SampleProduct{"Trumpet"})
  m["2019-03-21"] = append(m["2019-03-21"], SampleProduct{"Diamond"})
  json.NewEncoder(w).Encode(m)
}

func removeArticle(w http.ResponseWriter, r *http.Request) {
    log.Println("Remove article is called")
    params := mux.Vars(r)
    fmt.Println("params: ", params)

    id, _ := strconv.Atoi(params["id"])
    fmt.Println("id: ", id)

    fmt.Println("articles: ", articles)

    for i, item := range articles {
        if item.ID == id {
            articles = append(articles[:i], articles[i+1:]...)
        }
    }
    json.NewEncoder(w).Encode(articles)

}

func main() {
    // リクエストを裁くルーターを作成
    router := mux.NewRouter()

    // articles = append(articles,
    //     Article{ID: 1, Title: "Article1", Author: "Gopher", PostDate: "2019/1/1"},
    //     Article{ID: 2, Title: "Article2", Author: "Gopher", PostDate: "2019/2/2"},
    //     Article{ID: 3, Title: "Article3", Author: "Gopher", PostDate: "2019/3/3"},
    //     Article{ID: 4, Title: "Article4", Author: "Gopher", PostDate: "2019/4/4"},
    //     Article{ID: 5, Title: "Article5", Author: "Gopher", PostDate: "2019/5/5"},
    // )

    // エンドポイント
    //curl -d '{"name":"Musk"}' -X POST http://localhost:8000/purchaser
    router.HandleFunc("/purchaser", addPurchaser).Methods("POST")
    router.HandleFunc("/product", addProduct).Methods("POST")
    //curl -d '{"purchaser_id":"1", "product_id":"5"} -X POST http://localhost:8000/purchaser-product
    router.HandleFunc("/purchaser-product", addPurchaserProduct).Methods("POST")

    // router.HandleFunc("/purchaser/{purchaser_id}/product?start_date={start_date}&end_date={end_date}", getPurchaserProduct).Methods("GET")
    // router.HandleFunc("/articles", addArticle).Methods("POST")
    // router.HandleFunc("/articles", updateArticle).Methods("PUT")
    // router.HandleFunc("/articles/{id}", removeArticle).Methods("DELETE")


    //router.HandleFunc("/purchaser", addPurchaser).Methods("POST")
    //router.HandleFunc("/product", addProduct).Methods("POST")
    //router.HandleFunc("/purchaser-product", addPurchaserProduct).Methods("POST")
    router.HandleFunc("/purchaser/{purchaser_id}/product?start_date={start_date}&end_date={end_date}", getPurchaserProduct).Methods("GET")
    // Start Server
    log.Println("Listen Server ....")
    // 異常があった場合、処理を停止したいため、log.Fatal で囲む
    log.Fatal(http.ListenAndServe(":8000", router))
}
